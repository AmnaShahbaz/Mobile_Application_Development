package com.examples.labterminal

import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.examples.labterminal.adaptors.StudentAdaptor
import com.examples.labterminal.models.StudentModel
import com.examples.labterminal.services.Broadcast

class MainActivity : AppCompatActivity() {
    private lateinit var studentList:RecyclerView
    private lateinit var studentAdaptor: StudentAdaptor

    private val url = "https://run.mocky.io/v3/b8402fc5-ae31-4d98-bced-b5b3fede6d06"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val students = ArrayList<StudentModel>()
        students.add(StudentModel("abc", "fa18-bse-00", "1234"))
        studentList = findViewById(R.id.student_list)
        val queue = Volley.newRequestQueue(this)

        val request = JsonArrayRequest(
            Request.Method.GET,
            url,null,

            Response.Listener { res ->
                for(i in 0 until res.length()){
                    var obj = res.getJSONObject(i)
                    students.add(
                        StudentModel(
                            obj.getString("name"),
                            obj.getString("registerationNumber"),
                            obj.getString("phoneNumber")
                        )
                    )
                }
            },
            null
        )
        queue.add(request)

        studentAdaptor = StudentAdaptor(students)
        studentList.adapter = studentAdaptor
        studentList.layoutManager = LinearLayoutManager(this)


        airplaneMode()
    }

    private fun airplaneMode(){
        val receiver = Broadcast()
        val filter = IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION).apply {
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
        }
        registerReceiver(receiver, filter)
    }
}