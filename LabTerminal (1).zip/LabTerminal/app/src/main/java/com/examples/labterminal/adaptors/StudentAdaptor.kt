package com.examples.labterminal.adaptors

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.examples.labterminal.R
import com.examples.labterminal.models.StudentModel

class StudentAdaptor(val studentModels:ArrayList<StudentModel>):RecyclerView.Adapter<StudentAdaptor.StudentHolder>() {

    private lateinit var handleSend:onItemClickListener
    interface onItemClickListener {
        fun onItemClick(position: Int)
    }

    fun setOnItemClickListener(listener: onItemClickListener) {
        handleSend = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StudentHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.student_item, parent, false)
        return StudentHolder(view, handleSend)
    }

    override fun onBindViewHolder(holder: StudentHolder, position: Int) {
        holder.name.text = studentModels[position].name.toString()
        holder.registeration.text = studentModels[position].registertion.toString()
        holder.phone.text = studentModels[position].phone.toString()
    }

    override fun getItemCount(): Int {
        return studentModels.size
    }

    class StudentHolder(view: View, listener: StudentAdaptor.onItemClickListener):RecyclerView.ViewHolder(view){
        val name:TextView
        val registeration:TextView
        val phone:TextView
        val btnSend:Button
        init {
            name =view.findViewById(R.id.txt_name)
            registeration =view.findViewById(R.id.txt_reg)
            phone =view.findViewById(R.id.txt_phone)
            btnSend = view.findViewById(R.id.btn_sms)
            btnSend.setOnClickListener { listener.onItemClick(adapterPosition) }
        }

    }
}