package com.examples.labterminal.services

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log

class MyService:Service() {
    override fun onBind(p0: Intent?): IBinder? {
        return null
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("Started", "I am started")
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Stopped", "I am stopped")
    }

}