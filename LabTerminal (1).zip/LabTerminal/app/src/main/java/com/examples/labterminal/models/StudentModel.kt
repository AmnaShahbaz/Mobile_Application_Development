package com.examples.labterminal.models

class StudentModel(val name:String, val registertion:String, val phone:String)